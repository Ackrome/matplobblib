from ..forall import *
from .fr import *                   # Работа с моделями