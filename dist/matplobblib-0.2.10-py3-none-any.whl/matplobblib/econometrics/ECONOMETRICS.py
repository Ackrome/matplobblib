from  inspect import getsource
from .fr import *                   # Работа с моделями