# Описание
Замечательная библиотека разных структур для реализации на языке python

[Описание модуля `tvims`](https://github.com/Ackrome/matplobblib/tree/master/matplobblib/tvims#readme)



[Все, что используется в модуле aisd](https://github.com/Ackrome/matplobblib/tree/master/matplobblib/aisd)<br>
[Все, что используется в модуле tvims](https://github.com/Ackrome/matplobblib/tree/master/matplobblib/tvims)<br>
