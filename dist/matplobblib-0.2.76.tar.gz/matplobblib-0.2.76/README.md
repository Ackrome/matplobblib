# Описание

Замечательная библиотека разных структур для реализации на языке python

## Модули

* [aisd](https://github.com/Ackrome/matplobblib/tree/master/matplobblib/aisd)
* [tvims](https://github.com/Ackrome/matplobblib/tree/master/matplobblib/tvims#readme)
* [ml](https://github.com/Ackrome/matplobblib/tree/master/matplobblib/ml#readme)
